sleep 20s
killall conky
cd "/home/fernando/.conky/i3 Green Apple Desktop Background"
conky -c "/home/fernando/.conky/i3 Green Apple Desktop Background/Gotham" &
cd "/home/fernando/.conky/i3"
conky -c "/home/fernando/.conky/i3/Gotham" &
