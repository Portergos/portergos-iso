amixer set Master 5%- > /dev/null
